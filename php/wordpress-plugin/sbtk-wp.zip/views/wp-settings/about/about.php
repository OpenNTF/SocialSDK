<p>
The IBM Social Business Toolkit is your single source for developing integrations and leveraging IBM SmartCloud for Social Business and IBM Connections.
The toolkit provides a set of extensible tools and resources for developers who want to incorporate social capabilities into their applications and business processes.
</p>
<p>
For more information visit <a href="https://www.ibmdw.net/social/">https://www.ibmdw.net/social/</a>
</p>